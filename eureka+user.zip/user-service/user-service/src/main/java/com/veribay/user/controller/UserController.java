package com.veribay.user.controller;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.veribay.user.model.Users;
import com.veribay.user.service.UserService;

@RestController
@CrossOrigin
public class UserController {

	@Autowired
	private UserService service;

	@PostMapping("/registerUser")
	public String registerUser( @RequestParam("password") String password,@RequestParam("username") String username,
			@RequestParam("email") String email, @RequestParam("address") String address,
			@RequestParam("image") MultipartFile image) throws IOException {

		System.out.println(username+" "+password);
		Users user = new Users();
		UUID uuid = UUID.randomUUID();
		user.setId(uuid);
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setAddress(address);
		
	
		
		ByteBuffer profilePhotoBuffer = ByteBuffer.wrap(image.getBytes());
		user.setProfilephoto(profilePhotoBuffer);
		service.registerUser(user);
		return "Registered Successfully with id : " + user.getId();
	}

	@GetMapping("/getUsers")
	public Iterable<Users> getAllUsers() {
		return service.getAllUsers();
	}

}
