package com.veribay.model;

import java.util.UUID;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "creditcard")
public class Card {

	@PrimaryKey
	private UUID id;
	private Integer first;
	private Integer second;
	private Integer third;
	private Integer fourth;
	private Integer cvv;
	private Integer expirymnth;
	private Integer expiryyr;
	private String cardholder;
	public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public Integer getFirst() {
		return first;
	}
	public void setFirst(Integer first) {
		this.first = first;
	}
	public Integer getSecond() {
		return second;
	}
	public void setSecond(Integer second) {
		this.second = second;
	}
	public Integer getThird() {
		return third;
	}
	public void setThird(Integer third) {
		this.third = third;
	}
	public Integer getFourth() {
		return fourth;
	}
	public void setFourth(Integer fourth) {
		this.fourth = fourth;
	}
	public Integer getCvv() {
		return cvv;
	}
	public void setCvv(Integer cvv) {
		this.cvv = cvv;
	}
	public Integer getExpirymnth() {
		return expirymnth;
	}
	public void setExpirymnth(Integer expirymnth) {
		this.expirymnth = expirymnth;
	}
	public Integer getExpiryyr() {
		return expiryyr;
	}
	public void setExpiryyr(Integer expiryyr) {
		this.expiryyr = expiryyr;
	}
	public String getCardholder() {
		return cardholder;
	}
	public void setCardholder(String cardholder) {
		this.cardholder = cardholder;
	}
	
	

	

}
