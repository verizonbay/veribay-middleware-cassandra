package com.veribay.repository;

import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;

import com.veribay.model.Card;

public interface CardRepository extends CassandraRepository<Card, UUID>{

}
