package com.veribay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veribay.model.WishList;
import com.veribay.repository.WishListRepository;


@Service
public class WishListService {
	
	@Autowired
	private WishListRepository repository;
	

	public String registerWishListItem(WishList wishList) {
		repository.save(wishList);
		return "Product Added Successfully with id : "+wishList.getId();
	}
	
	public List<WishList> getAllWishListItem(){
		return repository.findAll();
	}
	
}
