package com.veribay.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;
import java.util.UUID;

import com.veribay.model.WishList;
import com.veribay.service.WishListService;

@RestController
@CrossOrigin
public class WishListController {

	@Autowired
	private WishListService service;
	
	@PostMapping("/addWishListItem")
	public String registerWishListItem(@RequestBody WishList wishList) {
		UUID uuid = UUID.randomUUID();
		wishList.setId(uuid);
		service.registerWishListItem(wishList);
		return service.registerWishListItem(wishList);
	}
	
	@GetMapping("/getAllWishListItem")
	public List<WishList> getAllWishListItem(){
		return service.getAllWishListItem();
	}
}
