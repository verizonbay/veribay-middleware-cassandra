package com.veribay.product.repository;

import java.util.UUID;

import org.springframework.data.cassandra.repository.CassandraRepository;

import com.veribay.product.model.Product;

public interface ProductRepository extends CassandraRepository<Product, UUID>{

}
