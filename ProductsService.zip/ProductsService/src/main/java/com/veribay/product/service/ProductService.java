package com.veribay.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veribay.product.model.Product;
import com.veribay.product.repository.ProductRepository;


@Service
public class ProductService {
	
	@Autowired
	private ProductRepository repository;
	

	public String registerProduct(Product product) {
		repository.save(product);
		return "Product Added Successfully with id : "+product.getId();
	}
	
	public List<Product> getProducts(){
		return repository.findAll();
	}
	
}
