package com.veribay.product.model;

import java.nio.ByteBuffer;
import java.util.UUID;

import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import com.datastax.driver.core.DataType.Name;

@Table(value = "products")
public class Product {

	@PrimaryKey
	private UUID id;
	private String username;
	private String product_type;
	private String product_name;
	private String product_category;
	private String short_desc;
	private String long_desc;
	private Integer product_minimumbid;
	private Integer product_price;

	@CassandraType(type = Name.BLOB)
	private ByteBuffer product_images;

	public UUID getId() {
		return id;
	}

	public ByteBuffer getProduct_images() {
		return product_images;
	}

	public void setProduct_images(ByteBuffer product_images) {
		this.product_images = product_images;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getProduct_type() {
		return product_type;
	}

	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public String getShort_desc() {
		return short_desc;
	}

	public void setShort_desc(String short_desc) {
		this.short_desc = short_desc;
	}

	public String getLong_desc() {
		return long_desc;
	}

	public void setLong_desc(String long_desc) {
		this.long_desc = long_desc;
	}

	public Integer getProduct_minimumbid() {
		return product_minimumbid;
	}

	public void setProduct_minimumbid(Integer product_minimumbid) {
		this.product_minimumbid = product_minimumbid;
	}

	public Integer getProduct_price() {
		return product_price;
	}

	public void setProduct_price(Integer product_price) {
		this.product_price = product_price;
	}

}
