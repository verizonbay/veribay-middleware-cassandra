package com.veribay.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.UUID;

import com.veribay.product.model.Product;
import com.veribay.product.service.ProductService;

@RestController
@CrossOrigin
public class ProductController {

	@Autowired
	private ProductService service;
	
	@PostMapping("/registerProduct")
	public String registerProduct(@RequestParam("username") String username,@RequestParam("product_type") String product_type,
			@RequestParam("product_name") String product_name, @RequestParam("product_category") String product_category,
			@RequestParam("short_desc") String short_desc,@RequestParam("long_desc") String long_desc,
			@RequestParam("product_minimumbid") Integer product_minimumbid,@RequestParam("product_price") Integer product_price,
			@RequestParam("product_images") MultipartFile product_images) throws IOException {
		
		Product product=new Product();
		UUID uuid = UUID.randomUUID();
		product.setId(uuid);
		product.setLong_desc(long_desc);
		product.setProduct_category(product_category);
		product.setProduct_minimumbid(product_minimumbid);
		product.setProduct_name(product_name);
		product.setProduct_price(product_price);
		product.setProduct_type(product_type);
		product.setShort_desc(short_desc);
		product.setUsername(username);
		
		
		ByteBuffer productImagesBuffer = ByteBuffer.wrap(product_images.getBytes());
		product.setProduct_images(productImagesBuffer);
		service.registerProduct(product);
		return service.registerProduct(product);
	}
	
	@GetMapping("/getProducts")
	public List<Product> getProducts(){
		return service.getProducts();
	}
}
